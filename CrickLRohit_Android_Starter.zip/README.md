# CrickLRohit — Android Studio starter project

Configured for **local tennis-ball cricket**.

## Current working starter features
- Set two team names and overs per innings
- Score runs (0, 1, 2, 3, 4, 6)
- Add wide, no-ball, bye and leg-bye runs
- Track team total, wickets, overs, extras, fours and sixes
- Undo the most recent scoring action
- Switch from first to second innings and show the target
- Start a new match

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Allow Gradle sync; install Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location after a successful build.

## Important limitations
This is a starter project, not yet a complete tournament-management app. It does not yet include player-by-player batting/bowling cards, full dismissal selection, automatic strike rotation, tournament fixtures, points table/NRR, persistent match history, or WhatsApp sharing. Those features need further implementation and testing before use in an official tournament.
