package com.example.cricketscorer

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.app.AlertDialog
import android.text.InputType
import java.util.Locale

class MainActivity : Activity() {
    private var teamA = "Team A"
    private var teamB = "Team B"
    private var battingFirst = true
    private var innings = 1
    private var total = 0
    private var wickets = 0
    private var legalBalls = 0
    private var target = 0
    private var extras = 0
    private var fours = 0
    private var sixes = 0
    private val history = mutableListOf<State>()
    private lateinit var scoreText: TextView
    private lateinit var overText: TextView
    private lateinit var detailText: TextView
    private lateinit var statusText: TextView
    private lateinit var root: LinearLayout
    private var maxOvers = 20

    data class State(val total: Int, val wickets: Int, val legalBalls: Int, val extras: Int, val fours: Int, val sixes: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showSetup()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = 16f
        setOnClickListener { action() }
    }
    private fun label(text: String, size: Float, color: Int = Color.DKGRAY): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        setPadding(dp(8), dp(6), dp(8), dp(6))
    }
    private fun newRoot(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(12), dp(16), dp(12))
        setBackgroundColor(Color.rgb(246, 248, 246))
    }
    private fun add(parent: LinearLayout, view: View, weight: Float = 0f) {
        parent.addView(view, LinearLayout.LayoutParams(-1, if (weight > 0) 0 else -2, weight))
    }

    private fun showSetup() {
        root = newRoot()
        add(root, label("🏏 CrickLRohit", 26f, Color.rgb(11,77,43)))
        add(root, label("Local Tennis-Ball Cricket • Create a match", 18f))
        val a = EditText(this).apply { hint = "Team 1 name"; setText(teamA) }
        val b = EditText(this).apply { hint = "Team 2 name"; setText(teamB) }
        val overs = EditText(this).apply { hint = "Overs (e.g. 20)"; inputType = InputType.TYPE_CLASS_NUMBER; setText("$maxOvers") }
        add(root, a); add(root, b); add(root, overs)
        add(root, button("Start Match") {
            teamA = a.text.toString().trim().ifEmpty { "Team A" }
            teamB = b.text.toString().trim().ifEmpty { "Team B" }
            maxOvers = (overs.text.toString().toIntOrNull() ?: 20).coerceAtLeast(1)
            resetMatch()
            showScorer()
        })
        add(root, label("Features: runs, wickets, wides, no-balls, byes, leg-byes, over tracking, target, undo and innings switch.", 14f))
        setContentView(root)
    }

    private fun resetMatch() {
        innings = 1; battingFirst = true; total = 0; wickets = 0; legalBalls = 0
        target = 0; extras = 0; fours = 0; sixes = 0; history.clear()
    }

    private fun saveState() { history.add(State(total, wickets, legalBalls, extras, fours, sixes)) }
    private fun currentBatting() = if (battingFirst) teamA else teamB
    private fun currentBowling() = if (battingFirst) teamB else teamA
    private fun overString(): String = "${legalBalls / 6}.${legalBalls % 6}"
    private fun addRuns(runs: Int, legal: Boolean = true, extra: Boolean = false) {
        if (isFinished()) return
        saveState()
        total += runs
        if (legal) legalBalls++
        if (extra) extras += runs
        if (runs == 4 && !extra) fours++
        if (runs == 6 && !extra) sixes++
        refresh()
        if (isFinished()) showFinishMessage()
    }
    private fun addWicket() {
        if (isFinished()) return
        saveState(); wickets++; legalBalls++; refresh()
        if (isFinished()) showFinishMessage()
    }
    private fun isFinished() = wickets >= 10 || legalBalls >= maxOvers * 6 || (innings == 2 && total >= target && target > 0)
    private fun showScorer() {
        root = newRoot()
        root.addView(ScrollView(this).apply {
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                add(this, label("🏏 CrickLRohit", 24f, Color.rgb(11,77,43)))
                scoreText = label("", 34f, Color.rgb(11,77,43)); add(this, scoreText)
                overText = label("", 20f); add(this, overText)
                detailText = label("", 15f); add(this, detailText)
                statusText = label("", 16f, Color.rgb(11,77,43)); add(this, statusText)
                add(this, label("ADD RUNS", 17f))
                val runs = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
                listOf("0","1","2","3","4","6").forEach { s ->
                    runs.addView(button(s) { addRuns(s.toInt()) }, LinearLayout.LayoutParams(0, dp(58), 1f))
                }
                add(this, runs)
                add(this, label("EXTRAS", 17f))
                val ex1 = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
                ex1.addView(button("Wide +1") { addRuns(1, legal = false, extra = true) }, LinearLayout.LayoutParams(0, dp(54), 1f))
                ex1.addView(button("No-ball +1") { addRuns(1, legal = false, extra = true) }, LinearLayout.LayoutParams(0, dp(54), 1f))
                add(this, ex1)
                val ex2 = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
                ex2.addView(button("Bye +1") { addRuns(1, extra = true) }, LinearLayout.LayoutParams(0, dp(54), 1f))
                ex2.addView(button("Leg-bye +1") { addRuns(1, extra = true) }, LinearLayout.LayoutParams(0, dp(54), 1f))
                add(this, ex2)
                add(this, button("WICKET") { addWicket() })
                val actions = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
                actions.addView(button("Undo") { undo() }, LinearLayout.LayoutParams(0, dp(54), 1f))
                actions.addView(button("Change Strike*") {
                    AlertDialog.Builder(this@MainActivity).setMessage("Strike tracking is not automatic in this starter version. Remember to change the striker after odd runs and at the end of each over.").setPositiveButton("OK", null).show()
                }, LinearLayout.LayoutParams(0, dp(54), 1f))
                add(this, actions)
                add(this, button("End Innings / Next Innings") { nextInnings() })
                add(this, button("New Match") { showSetup() })
                add(this, label("*This starter app tracks team totals and innings. Individual batter/bowler cards and advanced dismissal rules can be added next.", 13f))
            })
        })
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        if (!::scoreText.isInitialized) return
        scoreText.text = "${currentBatting()}\n$total/$wickets"
        overText.text = "Overs: ${overString()} / $maxOvers"
        detailText.text = "Innings $innings • Extras: $extras • 4s: $fours • 6s: $sixes\nBowling team: ${currentBowling()}" +
            if (innings == 2 && target > 0) "\nTarget: $target • Need ${maxOf(0, target-total)} runs" else ""
        statusText.text = if (isFinished()) "INNINGS COMPLETE" else "Live score"
    }
    private fun undo() {
        if (history.isEmpty()) { Toast.makeText(this, "Nothing to undo", Toast.LENGTH_SHORT).show(); return }
        val s = history.removeAt(history.lastIndex)
        total=s.total; wickets=s.wickets; legalBalls=s.legalBalls; extras=s.extras; fours=s.fours; sixes=s.sixes
        refresh()
    }
    private fun nextInnings() {
        if (innings == 1) {
            target = total + 1; innings = 2; battingFirst = false
            total=0; wickets=0; legalBalls=0; extras=0; fours=0; sixes=0; history.clear()
            refresh()
        } else {
            AlertDialog.Builder(this).setTitle("Match Summary")
                .setMessage("$teamA and $teamB\nTarget: $target\n${currentBatting()}: $total/$wickets in ${overString()} overs")
                .setPositiveButton("OK", null).show()
        }
    }
    private fun showFinishMessage() {
        AlertDialog.Builder(this).setTitle("Innings complete")
            .setMessage("${currentBatting()} scored $total/$wickets in ${overString()} overs.")
            .setPositiveButton("OK", null).show()
    }
}